<?php
/**
 * Plugin Name: 픽담 운영 고정장치
 * Description: 사이트맵 캐시를 끄고, IndexNow 키를 사이트 최상위에서 응답하고, 페이지에도 Rank Math 메타를 REST로 열어 준다. 손으로 반복해야 했던 설정 작업을 영구히 없애는 장치.
 * Version: 1.0.0
 * Author: 픽담 자동화
 * License: GPL-2.0-or-later
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ── 1) 사이트맵 캐시 비활성 ───────────────────────────────────────────── */
add_filter('rank_math/sitemap/enable_caching', '__return_false');

/* ── 2) IndexNow 키를 사이트 최상위에서 응답 ──────────────────────────── */
define('PICKDAM_INDEXNOW_KEY', '3073d0f9a62c8f5aa955b604ff3ed520');

add_action('init', function () {
    $key  = PICKDAM_INDEXNOW_KEY;
    $uri  = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    $path = parse_url($uri, PHP_URL_PATH);
    if ($path !== '/' . $key . '.txt') {
        return;
    }
    nocache_headers();
    status_header(200);
    header('Content-Type: text/plain; charset=UTF-8');
    header('X-Robots-Tag: noindex');
    echo $key;
    exit;
}, 1);

/* ── 3) 페이지에도 Rank Math 메타 REST 등록 ───────────────────────────── */
add_action('init', function () {
    $keys = array(
        'rank_math_focus_keyword',
        'rank_math_description',
        'rank_math_title',
    );
    foreach ($keys as $key) {
        register_post_meta('page', $key, array(
            'show_in_rest'  => true,
            'single'        => true,
            'type'          => 'string',
            'auth_callback' => function () {
                return current_user_can('edit_pages');
            },
        ));
    }
});
