<?php
/**
 * Plugin Name: 픽담 운영 고정장치
 * Description: 사이트맵 캐시 비활성, IndexNow 키 루트 응답, 페이지 Rank Math 메타 REST 개방, 글별·댓글 피드 noindex.
 * Version: 1.1.0
 * Author: 픽담 자동화
 * License: GPL-2.0-or-later
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ── 1) 사이트맵 캐시 비활성 ───────────────────────────────────────────── */
add_filter('rank_math/sitemap/enable_caching', '__return_false');

/* ── 2) IndexNow 키를 사이트 최상위에서 응답 ──────────────────────────── */
define('PICKDAM_INDEXNOW_KEY', '3073d0f9a62c8f5aa955b604ff3ed520');

add_action('init', function () {
    $key  = PICKDAM_INDEXNOW_KEY;
    $uri  = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    $path = parse_url($uri, PHP_URL_PATH);
    if ($path !== '/' . $key . '.txt') {
        return;
    }
    nocache_headers();
    status_header(200);
    header('Content-Type: text/plain; charset=UTF-8');
    header('X-Robots-Tag: noindex');
    echo $key;
    exit;
}, 1);

/* ── 3) 페이지에도 Rank Math 메타 REST 등록 ───────────────────────────── */
add_action('init', function () {
    $keys = array(
        'rank_math_focus_keyword',
        'rank_math_description',
        'rank_math_title',
    );
    foreach ($keys as $key) {
        register_post_meta('page', $key, array(
            'show_in_rest'  => true,
            'single'        => true,
            'type'          => 'string',
            'auth_callback' => function () {
                return current_user_can('edit_pages');
            },
        ));
    }
});

/* ── 4) 피드는 색인 대상이 아니다 (2026-10-13) ────────────────────────
 * 마크토 실측: 구글 서치콘솔 미색인 목록에 글별 RSS 피드와 댓글 피드가 잡혀
 * 숫자만 부풀리고 있다(/…/feed/ 와 /comments/feed/ 둘 다 HTTP 200).
 * robots.txt 로 막으려 했으나 서버에 실제 robots.txt 파일이 있어 Rank Math
 * 편집기가 잠겨 있다(실측: "robots.txt 파일을 쓸 수 없습니다").
 * 그래서 헤더로 처리한다 — Disallow 는 '차단됨'으로 남지만 noindex 는 색인에서
 * 실제로 빠진다. 사이트 전체 /feed/ 는 WebSub 통지에 쓰므로 그대로 둔다.
 */
add_action('template_redirect', function () {
    if (!is_feed()) {
        return;
    }
    $path = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '', PHP_URL_PATH);
    if ($path === '/feed/' || $path === '/feed') {
        return;   // 사이트 전체 피드는 유지
    }
    header('X-Robots-Tag: noindex, follow', true);
}, 1);
